# # program to check pass or fail in exam
# num = int(input("Enter the total number of subject : "))
# list_1 = []      # list containing marks obtained in each subject
# list_2 = []      # list containing total marks of each subject
# sum, total = 0, 0
#
# for i in range(num):
#     print("Enter the marks for subject :", i+1)
#     marks_obtained = int(input())
#     list_1.append(marks_obtained)
#     print("Enter the total marks for subject :", i+1)
#     total_marks = int(input())
#     list_2.append(total_marks)
#
# for i in range(num):
#     sum = sum + list_1[i]
#     total = total + list_2[i]
#
# percentage_marks = (sum / total)*100
#
# if percentage_marks > 35:
#     print("Congratulations ! You are pass. You have got",percentage_marks,"%")
# else:
#     print("Sorry ! You are failed in the exam.")

# k = ['s1', 'd3', 'c4', 'h1', 'c3', 'hk']
#
# for i in range(len(k)):
#     for j in range(len(k)):
#         if k[i][1] == k[j][1] and i != j:
#             pp = k.pop(j)
#             k.insert(i,pp)
# print(k)
# ===============================================================
k2 = ['s1', 'd3', 'c4', 'h1', 'c3', 'h1']
5


# def func(var):
#     print(var)
#     for i in range(len(var)):
#         for j in range(len(var)):
#             if var[i][1] == var[j][1] and i != j:
#                 match1 = var.pop(j)
#                 var.insert(0, match1)
#                 match2 = var.pop(i)
#                 var.insert(0, match2)
#     return var
#
#
# sequence = func(k2)
# print(sequence)
# ====================================================================
# ans = lambda n: 1 if n == 0 else n * ans(n - 1)
# print(ans(5))

# l = []
#
# length = int(input("enter the length of the list"))
# i = 0
# while i < length:
#     num = int(input('enter the items in list'))
#     l.append(num)
#     i += 1
#
# l.sort()
# print(l)