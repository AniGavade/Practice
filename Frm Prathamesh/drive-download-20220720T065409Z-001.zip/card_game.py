import random

deck = []
suits = ["S", "H", "C", "D"]  # s = spades,h=hearts,c=clubs,d=hearts
vals = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]


def CreateDeck():
    for suit in suits:
        for val in vals:
            item = suit + val
            deck.append(item)

    return deck


full_suit = CreateDeck()
print(full_suit)

for i in range(len(full_suit)):
    def shuffled_suit(var):
        random_card = random.choice(var)
        return random_card


    returned = shuffled_suit(full_suit)

    temp = full_suit[i]
    idx = full_suit.index(returned)
    full_suit[i] = full_suit[idx]
    full_suit[idx] = temp

print(full_suit)

shuffled = full_suit.copy()
print(shuffled)
# print(len(shuffled))
# print(type(shuffled))

player_1 = []
player_2 = []
player_3 = []
player_4 = []

num_card = int(input("How many cards do you want to give each player :\n"))

while len(shuffled) > (52 - (num_card * 4)):

    if len(shuffled) % 4 == 0:
        card_to_distribute = shuffled.pop(0)
        player_1.append(card_to_distribute)
    elif len(shuffled) % 4 == 3:
        card_to_distribute = shuffled.pop(0)
        player_2.append(card_to_distribute)
    elif len(shuffled) % 4 == 2:
        card_to_distribute = shuffled.pop(0)
        player_3.append(card_to_distribute)
    elif len(shuffled) % 4 == 1:
        card_to_distribute = shuffled.pop(0)
        player_4.append(card_to_distribute)

# print(player_1)
# print(player_2)
# print(player_3)
# print(player_4)


print()
print("Player 1 now its your turn.")
print()

counter = 1
choice = 2
discarded_card = ""

while True:
    if counter % 4 == 1:
        new_card = shuffled.pop()
        # player_1.append(new_card)
        if choice == 1:
            player_1.append(discarded_card)
        elif choice == 2:
            player_1.append(new_card)
        print(player_1)
        print()
        discarded_card = input("Which card do you want to discard from your cards :\n").upper()
        player_1.remove(discarded_card)
        counter += 1

        print(discarded_card)
        print()
        print("Player 2 now its your turn.")
        print()
        print(player_2)
        print()
        choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))

    elif counter % 4 == 2:
        new_card = shuffled.pop()
        if choice == 1:
            player_2.append(discarded_card)
        elif choice == 2:
            player_2.append(new_card)
        print(player_2)
        print()
        discarded_card = input("Which card do you want to discard from your cards :\n").upper()
        player_2.remove(discarded_card)
        counter += 1

        print(discarded_card)
        print()
        print("Player 3 now its your turn.")
        print()
        print(player_3)
        print()
        choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))

    elif counter % 4 == 3:
        new_card = shuffled.pop()
        if choice == 1:
            player_3.append(discarded_card)
        elif choice == 2:
            player_3.append(new_card)
        print(player_3)
        print()
        discarded_card = input("Which card do you want to discard from your cards :\n").upper()
        player_3.remove(discarded_card)
        counter += 1

        print(discarded_card)
        print()
        print("Player 4 now its your turn.")
        print()
        print(player_4)
        print()
        choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))

    elif counter % 4 == 0:
        new_card = shuffled.pop()
        if choice == 1:
            player_2.append(discarded_card)
        elif choice == 2:
            player_4.append(new_card)
        print(player_4)
        print()
        discarded_card = input("Which card do you want to discard from your cards :\n").upper()
        player_4.remove(discarded_card)
        counter += 1

        print(discarded_card)
        print()
        print("Player 1 now its your turn.")
        print()
        print(player_1)
        print()
        choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))