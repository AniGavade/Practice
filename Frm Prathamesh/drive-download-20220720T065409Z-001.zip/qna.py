# a = "nitin"
# b = ''
#
# for letter in a:
#     b = b + letter + "-"
# ans = b.strip('-')
# print(b)


# Input = "Djka1sjsjs2anns4ksmsm3"
# Output - "1234 <all alphabets>"
# print(f'Input : {Input}')
#
# num = []
# char = []
#
# list(map(lambda a: num.append(a) if a.isdigit() else char.append(a), Input))
# ans = "".join(num) + "".join(char)
# print(f'Output : {ans}')


# Input = 'BC4A1D32E5'
# # Output: ABCDE12345
# print(f'Input : {Input}')
#
# num = []
# char = []
#
# list(map(lambda a: num.append(a) if a.isdigit() else char.append(a), Input))
# # num.sort()
# # char.sort()
# ans = "".join(sorted(char)) + "".join(sorted(num))
# print(f'Output : {ans}')


# d = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
# ans = list(d.items())
# ans.reverse()
# print(ans)
# d = dict(ans)
# print(d)

# reverse dictionary without using inbuilt function
# d = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}
# ans = list(d.items())
# another = []
# for ele in range(len(ans)):
#     another.insert(0, ans[ele])
#
# d = dict(another)
# print(d)


# d = {1: {'a', 'b'}, 2: 'c'}
# ele = list(d[1])
# ans = ele[1]
# print(ans)

# # WAP to create dict from two list one as keys and other as values
# l1 = ['a', 'c', 'e', 'e', 'm', 'q', 'y']
# m1 = [1, 8, 6, 2, 9, 2, 6]
#
# lst = dict(zip(l1, m1))
# print(lst)

# # dictionary = {a[1]: a[0] for a in lst}
# # print(dictionary)


# # WAP to create dict from list. keys should be the element of list and values should be there count in list.
# l1 = ['a', 'c', 'e', 'e', 'm', 'q', 'y', 'y', 'a', 'e']
# d = {a : l1.count(a) for a in l1}
# print(d)

# l = (1, 2, [3, 4])
# print(l)
# # output --> (1,2,[3,5])
#
# l[2][1] = 5    # we can change mutable element inside tuple easily
# print(l)
#
# l[2].append(6)
# print(l)


# find prime numbers in given range
# numbers = range(10)
#
#
# def prime(num):
#     if num > 1:
#         ans = list(map(lambda a: True if num % a == 0 else False, range(2, num)))
#         # print('***',ans)
#         if any(ans):
#             # print(ans)
#             return False
#         else:
#             return num
#
#
# answer = list(filter(prime, numbers))
# print(answer)


try:
    print(10/0)
except ZeroDivisionError as msg:
    print(msg)
