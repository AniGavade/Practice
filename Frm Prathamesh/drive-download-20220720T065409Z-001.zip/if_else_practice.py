# Write a program to check whether a person is eligible for voting or not. (accept age from user)

# age = int(input("Enter your age :"))
# if age > 18:
#     print("You are eligible for voting.")
# else:
#     print("You are not eligible for voting.")

# print("=================================================================================================")

# Write a program to check whether a number entered by user is even or odd.

# number = int(input("Enter a number : "))
# if number % 2 == 0:
#     print("Even number")
# else:
#     print("Odd number")

# print("=================================================================================================")

# Write a program to check whether a number is divisible by 7 or not.

# number = int(input("Enter a number : "))
# if number % 7 == 0:
#     print("Number is divisible by 7")
# else:
#     print("Number is not divisible by 7")

# print("=================================================================================================")

# Write a program to display "Hello" if a number entered by user is a multiple of five ,
# otherwise print "Bye".

# number = int(input("Enter a number : "))
# if number % 5 == 0:
#     print("Hello")
# else:
#     print("Buy")

# print("=================================================================================================")

# Write a program to calculate the electricity bill (accept number of unit from user) according to the following criteria :
#       Unit                                                     Price
# First 100 units                                             no charge
# Next 100 units                                              Rs 5 per unit
# After 200 units                                             Rs 10 per unit

# number = int(input("Enter the number of units : "))
# if number <= 100 :
#     bill = 0
# elif number > 100 and number <= 200:
#     bill = (100 * 0) + (number - 100) * 5
# else:
#     bill = (100 * 0) + (100 * 5) + (number - 200) * 10
# print("Total bill =",bill)

# print("=================================================================================================")

# Write a program to display the last digit of a number.

# num = int(input("Enter a number :"))
# print("last digit of a number is :",num % 10)

# print("=================================================================================================")

# Write a program to check whether the last digit of a number( entered by user ) is
# divisible by 3 or not.

# num = int(input("Enter a number :"))
# last_digit = num % 10
# if last_digit % 3 == 0:
#     print("Last digit of a number is divisible by 3")
# else:
#     print("Last digit of a number is not divisible by 3")

# print("=================================================================================================")

# Write a program to accept percentage from the user and display the grade according to the following criteria:

#          Marks                                    Grade
#          > 90                                       A
#          > 80 and <= 90                             B
#          >= 60 and <= 80                            C
#          below 60                                   D

# num = int(input("Enter your percentage :"))
# if num > 90:
#     print("Grade - A")
# elif 80 < num <= 90:        # equal to num <= 90 and num > 80
#     print("Grade - B")
# elif 60 <= num <= 80:
#     print("Grade - C")
# else:
#     print("Grade - D")

# print("=================================================================================================")

# Write a program to accept the cost price of a bike and display the road tax to be paid according to the following criteria :
#       Cost price (in Rs)                             Tax
#         > 100000                                     15 %
#         > 50000 and <= 100000                        10 %
#         <= 50000                                      5 %

# price = int(input("Enter the price of bike :"))
# if price > 100000:
#     tax = price * 0.15
# elif 50000 < price <= 100000:
#     tax = price * 0.10
# elif price <= 50000:
#     tax = price * 0.05
# print("Total tax is :",tax)

# print("=================================================================================================")

# Write a program to check whether a years is leap year or not.

# year = int(input("Enter a year :"))
# if year % 100 == 0:
#     if year % 400 == 0:
#         print("Entered year is a leap year.")
#     else:
#         print("Entered year is not a leap year.")
# else:
#     if year % 4 == 0:
#         print("Entered year is a leap year.")
#     else:
#         print("Entered year is not a leap year.")

# print("=================================================================================================")

# Write a program to accept a number from 1 to 7 and display the name of the day like 1 for Sunday , 2 for Monday and so on.

# number = int(input("Enter a number between 1 to 7 :"))
# if number == 1:
#     print("Sunday")
# elif number == 2:
#     print("Monday")
# elif number == 3:
#     print("Tuesday")
# elif number == 4:
#     print("Wednesday")
# elif number == 5:
#     print("Thursday")
# elif number == 6:
#     print("Friday")
# else:
#     print("Saturday")

# print("=================================================================================================")

# Accept any city from the user and display monument of that city.
#                   City                                 Monument
#                   Delhi                               Red Fort
#                   Agra                                Taj Mahal
#                   Jaipur                              Jal Mahal

# print("1. Delhi, 2. Agra, 3. Jaipur")
# city = input("Enter a city name from above list :")
# if city.lower() == 'delhi':
#     print("Monument name is Red Fort.")
# elif city.lower() == 'agra':
#     print("Monument name is Taj Mahal")
# elif city.lower() == 'jaipur':
#     print("Monument name is Jal Mahal.")
# else:
#     print("Please enter correct name of city.")

# print("=================================================================================================")

# Write a program to check whether a number entered is three digits number or not.

# number = int(input("Enter a number :"))
# div = number / 10
# if div >= 10.0 and div < 100.0:
#     print("Number is 3 digits number")
# else:
#     print("Number is not a 3 digits number")

# print("=================================================================================================")

# Write a program to find the largest number out of three numbers excepted from user.

# num_1 = int(input("Enter a first number :"))
# num_2 = int(input("Enter a second number :"))
# num_3 = int(input("Enter a third number :"))
# if num_1 > num_2:
#     if num_1 > num_3:
#         print(num_1,"is the largest number.")
#     else:
#         print(num_3,"is the largest number.")
# else:
#     if num_2 > num_3:
#         print(num_2, "is the largest number.")
#     else:
#         print(num_3, "is the largest number.")

# print("=================================================================================================")

# Accept the age, sex (‘M’, ‘F’), number of days and display the wages accordingly

#      Age	            Sex	        Wage/day
# >=18 and <30	         M	          700
#                        F	          750
# >=30 and <=40	         M	          800
#                        F	          850

# age = int(input("Enter your age : "))
# if 18 <= age < 30:
#     gender = input("Enter your sex M or F : ")
#     if gender.lower() == 'f':
#         print("wage/day = Rs. 750")
#     elif gender.lower() == 'm':
#         print("wage/day = Rs. 700")
#     else:
#         print("Enter correct gender.")
# elif 30 <= age <= 40:
#     gender = input("Enter your sex M or F : ")
#     if gender.lower() == 'f':
#         print("wage/day = Rs. 850")
#     elif gender.lower() == 'm':
#         print("wage/day = Rs. 800")
#     else:
#         print("Enter correct gender.")
# else:
#     print("Enter correct age.")

# print("=================================================================================================")

# x = []
# a = int(input("Enter size"))
# for i in range(a):
#     y = int(input("Enter the value"))
#     x.append(y * (i + 1))
# print(x)

# print("=================================================================================================")

# l = [10,20,30,40,50]
# l1 = [l[i] * (i+1) for i in range(len(l))]
# print(l1)

# print("=================================================================================================")

# num = int(input("Enter the number of rows :"))
# k = num * 2 - 1
#
# for i in range(num):
#     for j in range(i):
#         print(end=" ")
#     for j in range(k):
#         print("*",end="")
#     k -= 2
#     print()
# for i in range(num-1):
#     for j in range(num-1-(i+1)):
#         print(end=" ")
#     for j in range((i+1)*2+1):
#         print("*",end="")
#     print()

# print("=================================================================================================")

side = int(input("Enter the size :"))
for i in range(side):
    for j in range(side):
        if i == 0 or i == side - 1 or j == 0 or j == side - 1:
            print("=",end="")
        else:
            print(" ",end="")
    print()

# print("=================================================================================================")

b = int(input("enter the breadth:"))
l = int(input("enter the length:"))
for i in range(b):
    for j in range(l):
        if i == 0 or i == b-1 or j == 0 or j == l-1:
            print("*", end=" ")
        else:
            print(" ",end=" ")
    print()