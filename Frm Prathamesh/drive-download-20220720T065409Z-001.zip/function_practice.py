from functools import reduce

# def func(var=10,var1):
#     addition = var + var1
#     print(var + var1)
#
# func(20)


# lst = [4, 5, 6, 9, 7, 13, 12, 21, 26, 28]
# print(lst)
#
# even = list(filter(lambda a: a % 2 == 0, lst))
# print(even)
#
# double = list(map(lambda a: a * 2, even))
# print(double)
#
# addition = reduce(lambda a, b: a + b, double)
# print(addition)

# lst1 = [2, 6, 13, 26, 15]
# lst = [4, 5, 6, 9, 7, 13, 12, 21, 26, 28]
#
# is_present = list(filter(lambda a: True if a in lst else False, lst1))
# print(is_present)
# ===================================================================================
# string = "prathamesh"
#
# ans = list(map(lambda a: a, string))
# print(ans)
# print(*ans)
# for i in ans:
#     print(i,end=" ")
# print()
#
# str = 'prathamesh'
# def double(x):
#     print(x * 2, end=' ')
# result = list(map(double, str))
# print()
# #
# ans = ' '.join(list(map(lambda a: a * 2, str)))
# print(ans)

# ===================================================================================
# tup = (2,4,3,8,6,1,2)
#
# print(reduce(lambda a, b: a if a > b else b, tup))

# ====================================================================================
# decorator

# def div(a, b):
#     print(a / b)
#
#
# def smartDiv(func):
#     def innerDiv(a, b):
#         if a < b:
#             a, b = b, a
#         return func(a, b)
#
#     return innerDiv
#
#
# div1 = smartDiv(div)
# div1(2, 1)

# ===============================================================================
# def smartDiv(func):
#     def innerDiv(a, b):
#         if a < b:
#             a, b = b, a
#         return func(a, b)
#     return innerDiv
#
#
# @smartDiv
# def div(a, b):
#     print(a / b)
#
#
# div(2, 4)

# =============================================================================
# l = ['a','e','o','i','u']
# s = ['f','s','t','u','m','o','a']
#
# ans = filter(lambda a: a if a in l else False, s)
# print(ans)
# for i in ans:
#     print(i)
#
# ans = list(filter(lambda a: a if a in l else False, s))
# print(ans)

# =============================================================================
# def decorator_func(func):
#     print("decorator function1")
#
#     def inner(x, y):
#         print("inner function")
#         return func(x, y)
#
#     print("decorator function2")
#
#     return inner
#
#
# @decorator_func
# def multiply_func(a, b):
#     print(a * b)
#
#
# multiply_func(5, 2)

# =============================================================================
# def decorator_func(func):
#     print("decorator function1")
#
#     def inner(x, y):
#         print("inner function")
#         if x > 10:
#             x = 15
#         else:
#             x = x - 1
#         result = func(x, y)
#         print(result)
#
#     print("decorator function2")
#
#     return inner
#
#
# @decorator_func
# def multiply_func(a, b):
#     return a * b
#
#
# multiply_func(25, 20)

# ===============================================================================
# def decor(func):
#     print("decor")
#     def inner(str1, str2):
#         print("inner")
#         str3 = str1.upper()
#         str4 = str2.capitalize()
#         print("inner2")
#         return func(str3, str4)
#     print("decor2")
#     return inner
#
#
# @decor
# def string(a, b):
#     print("string")
#     print(f'{a} {b}')
#
#
# string("hello!", "good morning")

# =============================================================================
# def normal(func):
#     def inner():
#         str1 = func()
#         return str1.upper()
#     return inner
#
#
# @normal
# def main_func():
#     return "good morning"
#
#
# print(main_func())

# =================================================================================
# from datetime import datetime
#
#
# def log_datetime(func):
#     '''Log the date and time of a function'''
#
#     def wrapper():
#         print(f'Function: {func.__name__}\nRun on: {datetime.today().strftime("%Y-%m-%d %H:%M:%S")}')
#         print(f'{"-" * 30}')
#         func()
#
#     return wrapper
#
#
# @log_datetime
# def daily_backup():
#     print('Daily backup job has finished.')
# daily_backup()

# ==================================================================================

# def decorator(func):
#     def inner():
#         str1 = func()
#         return str1.upper()
#
#     return inner
#
#
# @decorator
# def string():
#     return "good morning"
#
#
# print(string())

# ==================================================================================

#
# def func(var):
#     def inner(*var1):
#
#         print(f"my name is {var1[0]} and my age is {var1[1]}")
#         return var(*var1)
#
#     return inner
#
# @func
# def display(name, age):
#     print(f"my name is {name} and my age is {age}")
#
#
# display("prathamesh",28)

# --------------------------------------------------------------------------------------

# def func(var):
#     def inner(name,age):
#         print(f"my name is {name} and my age is {age}")
#         name = "rohit"
#         age = 15
#
#         return var(name, age)
#
#     return inner
#
# @func
# def display(name, age):
#     print(f"my name is {name} and my age is {age}")
#
#
# display("prathamesh", 28)

# --------------------------------------------------------------------------------------

# def func(var):
#     def inner(a, b):
#         print("enhancing method :")
#         if a < b:
#             a, b = b, a
#         return var(a, b)
#
#     return inner
#
# @func
# def addition(a, b):
#     ans = a / b
#     print(ans)
#
#
# addition(2, 5)


# def fibonacci_numbers(nums):
#     x, y = 0, 1
#     for _ in range(nums):
#         x, y = y, x+y
#         yield x
#
#
# def square(nums):
#     for num in nums:
#         yield num**2
#
#
# print(sum(square(fibonacci_numbers(10))))

# lst = [1,2,3,4,5,6]
# def gen(x):
#     for i in range(len(x)):
#         yield x[i] + 1
#         yield x[i] * x[i]
#
# a = gen(lst)
#
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))


# def dscCity(city,country="India"):
#     print(f"{city} is in {country}")
#
# dscCity('pune')
# dscCity("mumbai")
# dscCity("sydney","usa")

# fib = lambda a: 1 if a == 0 else a * fib(a - 1)
#
# print(fib(5))

# ================================================================
# def decor1(var):         # var = inner of decor2
#     def inner():
#         print("=====")
#         print(var())
#         print("=====")
#
#     return inner
#
#
# def decor2(var):        # var = func ie. decor2(func)
#     def inner():
#         print("*****")
#         print(var())
#         print("*****")
#         return "Prathamesh"
#     return inner         # this inner returned to func()
#
#
# @decor1
# @decor2
# def func():
#     return "good morning"


# func()    # decor1(decor2(func))  >>>  decor1(inner)  >>>  inner() of decor1
#
# ======================================================================================
#
# def dictModify(fname, lname, age = 'None'):
#     person = {'first' : fname , 'last' : lname}
#
#     if age:
#         person['age'] = age
#
#     return person
#
# while True:
#     print("press 1 to quite the program anytime")
#     first_name = input("enter the first name")
#     print(first_name)
#     if first_name == "1":
#         break
#     print("press 1 to quite the program anytime")
#     last_name = input("enter the last name")
#     if last_name == "1":
#         break
#     person = dictModify(first_name,last_name)
#     print(person)
#
# ======================================================================================

#
# def calculator(var):
#     x = int(input("enter first value : "))
#     y = int(input("enter first value : "))
#     operator = input("enter operator : + ,- ,*,/ :")
#     print(var(x, y, operator))
#
#
# calculator(lambda x,y,operator : x+y if operator == "+" else x-y if operator == "-" else x*y if operator == "*" else x/y if operator=="/" else "No such operator found")

# ======================================================================================

# def square(var):
#     return var ** 2
#
#
# def cube(var):
#     return var ** 3
#
#
# func = [square, cube]
#
# for i in (5, 4, 7, 9):
#     val = map(lambda x: x(i), func)  # x = square,cube: [square(i),cube(i)]
#     print(list(val))

# ======================================================================================

# def decor_fun(var):
#     def inner(*marks):
#         for i in marks:
#             if i > 75:
#                 print("distinction")
#             else:
#                 res = var(i)
#                 print(res)
#     return inner
#
#
# @decor_fun
# def main(*marks):
#     for i in marks:
#         if i > 40:
#             return "pass"
#         else:
#             return "fail"
#
#
# main(34, 75, 80, 22, 90, 56)
