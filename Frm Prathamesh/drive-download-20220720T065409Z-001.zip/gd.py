# while True:
#     travel = int(input('''
#   WHERE YOU WANT TO GO
#
#   1 nagpur to pune
#   2 aurangabad to pune
#   3 mumbai to pune
#
#                  '''))
#
#     if travel == 1:
#         type_adult = int(input('''
#       1 adult
#       2 kid (above 10 yr)
#       3 kid (below 10 yr)
#       4 handicap
#       '''))
#         if type_adult == 1:
#             print("you have to pay rs 500")
#         elif type_adult == 2:
#             print("you have to pay rs 300")
#         elif type_adult == 3:
#             print("no fair for kid")
#         elif type_adult == 4:
#             print("you have to pay rs 150")
#     if travel == 2:
#         type_adult = int(input('''
#       1 adult
#       2 kid (above 10 yr)
#       3 kid (below 10 yr)
#       4 handicap
#       '''))
#         if type_adult == 1:
#             print("you have to pay rs 1000")
#         elif type_adult == 2:
#             print("you have to pay rs 600")
#         elif type_adult == 3:
#             print("no fair for kid")
#         elif type_adult == 4:
#             print("you have to pay rs 350")
#     if travel == 3:
#         type_adult = int(input('''
#        1 adult
#        2 kid (above 10 yr)
#        3 kid (below 10 yr)
#        4 handicap
#        '''))
#         if type_adult == 1:
#             print("you have to pay rs 1000")
#         elif type_adult == 2:
#             print("you have to pay rs 600")
#         elif type_adult == 3:
#             print("no fair for kid")
#         elif type_adult == 4:
#             print("you have to pay rs 350")
from urllib3.connectionpool import xrange

print("--------------------------------------------------------------------------------------------")
# while True:
#     travel = int(input('''
# WHERE YOU WANT TO GO
#
# 1 nagpur to pune
# 2 aurangabad to pune
# 3 mumbai to pune\n'''))
#     print("Enter the type of adult :")
#     adult_type = int(input('''
# 1 adult
# 2 kid (above 10 yr)
# 3 kid (below 10 yr)
# 4 handicap
#     '''))
#     if travel == 1 :
#         if adult_type == 1:
#             print("you have to pay rs 500")
#         elif adult_type == 2:
#             print("you have to pay rs 300")
#         elif adult_type == 3:
#             print("no fair for kid")
#         elif adult_type == 4:
#             print("you have to pay rs 150")
#         else:
#             print("Select correct adult type")
#             continue
#     elif travel == 2 :
#         if adult_type == 1:
#             print("you have to pay rs 1000")
#         elif adult_type == 2:
#             print("you have to pay rs 600")
#         elif adult_type == 3:
#             print("no fair for kid")
#         elif adult_type == 4:
#             print("you have to pay rs 350")
#         else:
#             print("Select correct adult type")
#             continue
#     elif travel ==3 :
#         if adult_type == 1:
#             print("you have to pay rs 1000")
#         elif adult_type == 2:
#             print("you have to pay rs 600")
#         elif adult_type == 3:
#             print("no fair for kid")
#         elif adult_type == 4:
#             print("you have to pay rs 350")
#         else:
#             print("Select correct adult type")
#             continue
#     else:
#         print("Select correct travel")
#         continue
#
#     print('''Do you want book another seat
# press 1. yes
#       2. no''')
#     re_book = int(input())
#     if re_book == 1:
#         continue
#     else:
#         break
# print("-----------------------------------------------------------------------------------------------")
# l = [45, 35, 75, 98]
# a = 35
# for i in l:
#     if i < a:
#         a = i
# if a <= 35:
#     print("fail")
# else:
#     print("pass")
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(i+1):
#         print(" ",end=" ")
#     for j in range(i,n):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(i,n):
#         # print("*",end=" ")
#         if i==0 or j==i or j==n-1:
#             print("*",end=" ")
#         else:
#             print(" ",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(2*i + 1):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(i+1):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n=5
# for i in range(0,n):
#     print(" " * (n - i - 1) + "* " * (i + 1))
#
# n=5
# for i in range(0,n):
#     for j in range(n - i - 1):
#         print(end=" ")
#     for j in range(i + 1):
#         print("*", end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n=5
# for i in range(n):
#     print(" "*(n-i-1) + "*"*(2*i+1))
#
# n=5
# for i in range(n):
#     for j in range(n-i-1):
#         print(end=" ")
#     for j in range(2*i+1):
#         print("*",end="")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     print(" "*(i) + "* " * (n - i))
# n = 5
# for i in range(n):
#     for j in range(i):
#         print(end=" ")
#     for j in range(n-i):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     print(" " * (n-i-1) + "* " * (i + 1))
# for i in range(n-1):
#     print(" " * (i + 1) + "* " * (n - 1 - i))
#
# n = 5
# for i in range(n):
#     for j in range(n-i-1):
#         print(end=" ")
#     for j in range(i+1):
#         print("*",end=" ")
#     print()
# n = n - 1
# for i in range(n):
#     for j in range(i+1):
#         print(end=" ")
#     for j in range(n-i):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     print(" " * (n-i-1) + "* " * (i + 1))
# for i in range(n-1):
#     print(" " * (i + 1) + "* " * (n - 1 - i))
# for i in range(1,n):
#     print(" " * (n-i-1) + "* " * (i + 1))
# for i in range(n-1):
#     print(" " * (i + 1) + "* " * (n - 1 - i))
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(n - i):
#         print("*",end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")
# n = 5
# for i in range(n):
#     for j in range(n):
#         if i == 0 or j == n-1 or i == j:
#             print("*",end=" ")
#         else:
#             print(" ", end=" ")
#     print()
# print("-----------------------------------------------------------------------------------------------")

# lower_value = int(input("Enter the input:\n"))
# upper_value = int(input("Enter the input:\n"))
# for num in range(lower_value,upper_value+1):
#     if num > 1 :
#         for i in range(2,num):
#             if num % i == 0:
#                 break
# print("-----------------------------------------------------------------------------------------------")
# fibonacci series
# n = int(input("enter the no of values :\n"))
# first = 0
# second = 1
# for i in range(n):
#     print(first)
#     temp = first
#     first = second
#     second = first + temp

# print(first)
# print(second)
# for i in range(2,n):
#     third = first + second
#     print(third)
#     first = second
#     second = third
print("--------------------------------------------------------------------------------------------")
# prime number series
# num = int(input("enter the number of value you want :"))
# for i in range(num+1):
#     if i > 1 :
#         for j in range(2,i-1):
#             if i % j == 0:
#                 break
#         else:
#             print(i)
print("--------------------------------------------------------------------------------------------")

# l = [(10,20,40),(40,50,60),(70,80,90)]
# l2 = []
# for i in l:
#     t = list(i)
#     t[2] = 100
#     t = tuple(t)
#     l2.append(t)
# print(l2)


# import datetime
#
# date = datetime.datetime.now()
# print("{:%Y-%b-%d}".format(date))

# num = int(input("Enter the number"))
# num2 = num
#
# def counter(var):
#     count = 0
#     while var > 0:
#         var = var // 10
#         count = count + 1
#     return count
#
#
# total_digits = counter(num)
#
# value = 0
# for i in range(total_digits):
#     reminder = num2 % 10
#     num2 = num2 // 10
#     value = value + reminder ** total_digits
#
# if num == value:
#     print("armstrong number")
# else:
#     print("not a armstrong number")
print("--------------------------------------------------------------------------------------------")

# num = input("Enter the number :")
# length = len(num)
# add = 0
# for i in range(length):
#     num1 = 0
#     num1 = int(num[i])
#     add = add + (num1 ** length)
# print(add)
#
# if add == int(num):
#     print("armstrong")
# else:
#     print("not")
print("--------------------------------------------------------------------------------------------")

# Decorator with chaining example 3
# def out(func):
#     def inn():
#         x = func()
#         return x * x
#     return inn
# def out2(func):
#     def abc():
#         x = func()
#         return 2 * x
#     return abc
#
# @out
# @out2
# def num():
#     return 10
# print(num())

# dict_1 = {"a":"apple", "b":"banana", "c":"cherry", "g":"grapes", "g":"guava"}
# dict_1["p"] = "pineapple"
# dict_1.update({1: "fruits"})
# print(dict_1)


# fo = open("foo.txt", "r+")
# print("Name of the file: ", fo.name)
#
# # Assuming file has following 5 lines
# fo.write('This is 1st line\n')
# fo.write('This is 2nd line\n')
# fo.write('This is 3rd line\n')
# fo.write('This is 4th line\n')
# fo.write('This is 5th line\n')
# # This is 1st line
# # This is 2nd line
# # This is 3rd line
# # This is 4th line
# # This is 5th line
#
# # fo.seek(0)
# line = fo.readline()
# print(line)
#
# # Get the current position of the file.
# pos = fo.tell()
# print("Current Position: %d" % pos)
#
# # Close opend file
# fo.close()


# class A:
#     def method1(self):
#         print('method 1')
#
#
# class B(A):
#     def method2(self):
#         print('method B2')
#         super().method2()
#
#
# class C(A):
#     def method2(self):
#         print('method C2')
#         super().method1()

# class D(B, C):
#     def method3(self):
#         print('method 3')
#         super().method2()
# d = D()
# d.method3()

# l = []
# for num in range(100, 2000):
#     var = list(str(num))
#     mid = int(len(var) // 2)
#     # print(var)
#     num1, num2 = 0, 0
#     i, j = 0, 1
#     while i < mid:
#         num1 = var[i]
#         num2 = var[-j]
#         if num1 != num2:
#             break
#         else:
#           i += 1
#           j += 1`
#
#     if i == mid:
#         l.append(num)
# print(l)
#
# # print(l)
# l=[x for x in range(100,1001) if str(x)==str(x)[::-1]]
# print(l)

# a = []
# for i in range(10):
#     a.append(i*i)
# print(a)
# for a[i] in a:
#     print(a)
# print(a)

# g = [x*x for x in range(10)]
# # print(next(g))
# print(g[2])

# l = [(1, 3, 4), (2, 4, 6), (3, 8, 1)]
# print(l)
# List after bulk update : [(5, 7, 8), (6, 8, 10), (7, 12, 5)]
# for i in l:
#     # print(i)
#     idx = l.index(i)
#     temp = list(i)
#     temp1 = [x + 4 for x in temp]
#     temp = tuple(temp1)
#     l.remove(i)
#     l.insert(idx, temp)
#
# print(l)


# l = [[1], [], [], [5], [6], [], [], [5]]
# l1 = []
# for i in range(len(l)):
#     print(bool(l[i]))
#     if bool(l[i]) == False:
#         print(1)
#         continue
#     else:
#         print(2)
#         l1.append(l[i])
# print(l1)

# l = [5, 5, 2, 3, 4, 4, 8, 6, 4, 4, 2, 9, 4, 4]
# print(l)
#
# for i in range(len(l)-1, -1, -1):
#     if l.count(l[i]) > 1:
#         l.remove(l[i])
# print(l)

# l = [[1], [], [], [5], [6], [], [], [8]]
# for i in l:
#     print('index', l.index(i))
#     print(i)
#     print(bool(i))
#     print('before removing', l)
#     print('-------------------------------------------------------')
#     if bool(i) == False:
#         l.remove(i)
#         print('after removing', l)
#     else:
#         print('after removing', l)
# print(l)


# print(ord('p'))
# print(ord('P'))


# s2 = "+917709751122, 9909234345, +919848723786, 8474674633"
# s1 = []
# s = s2.split(',')
# for i in s:
#     a = i.strip()
#     if a.startswith('+91'):
#         continue
#     else:
#         s1.append(a)
# print(s1)

# s = '+919561489883 9422819890 +918605031487 8474525885'
# s1 = s.split(' ')
# l1 = []
# for i in s1:
#     if '+91' in i:
#         l1.append(i)

# print(l1)

# s = "ABC125684"
# num_str = ""
# char_str = ""
# for i in s:
#     if i.isdigit():
#         num_str = num_str + i
#     elif i.isalpha():
#         char_str = char_str + i
# print(char_str + num_str)

# s = "ABC125684"
# x, y = [x for x in s if x.isalpha()], [y for y in s if y.isdigit()]
# ans = x + y
# ans = "".join(ans)
# print(ans)

# s = 'abcdefgh'
# s1=''
# print(len(s))
# for i in range(len(s)):
#     s1 = s[i] + s1
# print(s1)


# l = ['a', 'c', 'e', 'e', 'm', 'q', 'y']
# m = [1, 8, 6, 2, 9, 2, 6]
#
# lst = zip(l, m)
# final = list(lst)
# print(final)
#
# sorted_list = sorted(final, key=lambda x: (x[0], x[1]))
# print(sorted_list)


# s = ['a', 'j', 'k', 'e', 'b', 'i', 'm', 'n', 'a']
#
# lst = ['a', 'e', 'i', 'o', 'u']
#
# x = list(filter(lambda a: a if a in s else False, lst))
# print(x)

# y = list(filter(lambda b: list(s).count(b) if b in s else False, x))
# print(y)


# import re
# # a = re.compile('ab')
# # reobj = a.finditer('abaaaaabaa')
# reobj = re.finditer('ab','abaaaaabaa')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())
# for i in reobj:
#     print(i.start(), '', i.group())


# import re
# reobj = re.finditer('[abc]','ra$uabvwbwxy')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())

# import re
# reobj = re.finditer('[^abc]','ra$uabvwbwxyZ')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())

# import re
# reobj = re.finditer('[a-z]','ra$uabvwbwxyZ')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())
#
# import re
# reobj = re.finditer('[A-Z]','ra$uabvwbwxyZ')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())

# import re
# reobj = re.finditer('[a-zA-Z0-9]','ra$uabvwbwxyZ')
# for i in reobj:
#     print(i.start(),'',i.group(),'',i.end())

# quantifiers

# import re
# var = 'hello   python developers.'
# var1 = var.replace(' ', '-')
# print(var1)
# # if we want to replace only one - in place of multiple white spaces we use re.sub()
# var2 = re.sub('\s+', '-', var)  # \s+ means string of white space characters.
# var3 = re.sub('\S+', '-', var)  # \S+ means string of non-white space characters.
# print(var2)
# print(var3)


# lst = [1, 8, 6, 9, 3, 5, 2]
#
# a = list(filter(lambda x: x if x % 2 != 0 else False, lst))
# print(a)
#
#
# string = input('enter the string :\n')
#
# print(string)
# lst = []
# for i in string:
#     if i not in lst:
#         lst.append(i)
#
#         print(f'{i} = {string.count(i)}')


# string = input('enter the string :\n')
# print(string)
# lst1 = []
# lst2 = []
# for i in string:
#     if i not in lst1:
#         lst1.append(i)
#         lst2.append(string.count(i))
# zipped_obj = list(zip(lst1, lst2))
# print(zipped_obj)
# sorted_list = sorted(zipped_obj, key=lambda a: a[1])
# print(sorted_list)
#
# lst = [2, 8, 6, 15, 9, 4, 11]
#
# a = sorted(lst, key=lambda x: x % 16, reverse=True)
# print(a)


# matrix = [
#     [1, 2, 3, 4],
#     [5, 6, 7, 8],
#     [9, 10, 11, 12],
#     ]
#
# matrix_transpose = [[row[i] for row in matrix] for i in range(4)]

# lst = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# l = lst[2:]
# l.remove(6)
# print(lst)


# sync
# async
# parallelism
# concurrence

# i/o bound
# cpu bound

# import threading
# import time
#
# def task():
#     my_lock.acquire()
#     print("lock aquired")
#     time.sleep(4)
#     print(" rohit patil")
#     my_lock.release()
#
# my_lock = threading.Lock()
# t = threading.Thread(target = task)
# t2 = threading.Thread(target= task)
# t.start()
# t2.start()

# first = "https://www.pdfdrive.com/learn-python-in-one-day-and-learn-it-well-python-for-beginners-with-hands-on-project-the-only-book-you-need-to-start-coding-in-python-immediately-d183833259.html"
#
# second = "https://www.pdfdrive.com/automate-the-boring-stuff-with-python-automate-the-boring-stuff-with-python-d26956384.html"
# lst = [first,second]
# import time
# import threading
# import requests
#
# def download(file,i):
#
#     pdf_file = requests.get(file).content
#     print("downloading pdf file")
#
#     with open(f"mypdf+{i}.pdf","wb") as myfile:
#         myfile.write(pdf_file)
#         print("file downloaded")
# i = 0
# for file in lst :
#     t = threading.Thread(target=download, args=(file, i))
#     i = i +1

#
# lst = [1, 2, 1, 3, 4, 5]
#
# ans = list(map(lambda a: sum(lst[a::-1]), range(len(lst))))
# print(ans)

# ----------------------------------------------------------------------------------------------------------------------

# Python program to get dictionary keys as list

# dict1 = {'a': 'Geeks', 'b': 'For', 'c': 'geeks'}
#
# print([*dict1], tuple(dict1))

# program to find anagram string
# line1 = input('enter the word')
# line2 = input('enter the word')
#
# a = list(map(lambda x: x if x in line1 else False, line2))
# b = list(map(lambda x: x if x in line2 else False, line1))
#
# if all(a) and all(b):
#     print('anagram string')
# else:
#     print('not anagram string')
#
# # ---------------------------------------------
#
# line1 = input('enter the word')
# line2 = input('enter the word')
#
# if sorted(line1) == sorted(line2):
#     print('anagram string')
# else:
#     print('not anagram string')


# s = 'abcgfgfgf'
# n=5
# s = "".join([s[i]for i in range(len(s))if i!=n-1])
# print(s)

# line1 = input('enter the word')
# line2 = input('enter the word')
#
# Result = list(map(lambda x,y: (x,y) if x in line2 and y in line1 else False, line1,line2))
#
# if all(Result):
#     print('anagram string')
# else:
#     print('not anagram string')


# Python3 implementation of the Deep
# copy and Shallow Copy
from copy import copy, deepcopy


# Class of Car
# class Car:
#     def __init__(self, name, colors):
#         self.name = name
#         self.colors = colors
#
#
# honda = Car("Honda", ["Red", "Blue"])
#
# # Deepcopy of Honda
# deepcopy_honda = deepcopy(honda)
# deepcopy_honda.colors.append("Green")
# print(deepcopy_honda.colors, honda.colors)
#
# # Shallow Copy of Honda
# copy_honda = copy(honda)
#
# copy_honda.colors.append("Green")
# print(copy_honda.colors, honda.colors)


# d = eval(input('dldjofeheofennfsd'))
# print(d)

# def fibo():
#     a, b = 0, 1
#     while True:
#         yield a
#         a, b = b, a + b
#
#
# for i in fibo():
#     if i >= 100:
#         break
#     print(i)

# from functools import reduce
# l = [1,2,3,4,5,1,2,5,4,8]
# x = reduce(lambda a, b: a if a > b else b, l)
# y = reduce(lambda a, b: a if b < a else b, list(filter(lambda c: c != x, l)))
# print(y)


str = 'fjgpoir;adlakjsoirjnkljalfjo'
lst = []

for char in str:
    if char not in lst:
        lst.append(char)
        count = str.count(char)
        print(char, ":", count)