# Q.1 Python Program for factorial of a number with and without recursion
# with recursion
# fact = (lambda a: 1 if a == 0 else a * fact(a - 1))
# num = int(input('enter the number whose factorial you want :\n'))
# print(f 'factorial of {num} is :', fact(num))
#
# # without recursion
# num = int(input('enter the number whose factorial you want :\n'))
# fact = 1
# for i in range(1, num + 1):
#     fact = fact * i
#
# print(f' factorial of {num} is :', fact)
# ----------------------------------------------------------------------------------------------------------------------

# Q.2 Python Program to check Armstrong Number

# number = int(input('enter the number to check whether it is armstrong or not :\n'))
#
# number = str(number)
# length = len(number)
# sum_ = 0
# for i in number:
#     digit = int(i)
#     sum_ += digit ** length
# if sum_ == int(number):
#     print(f'{int(number)} is a armstrong number')
# else:
#     print(f'{int(number)} is not a armstrong number')
# ----------------------------------------------------------------------------------------------------------------------

# Q.3 Python program to print all Prime numbers in an Interval
# def primeNumber(var):
#     global flag
#     if var > 1:
#         for num in range(2, var):
#             if var % num == 0:
#                 flag = 1
#                 break
#         if flag == 0:
#             # print(var)
#             return var
#
#
# for i in range(1, 100):
#     flag = 0
#     # primeNumber(i)
#     prime_number = primeNumber(i)
#     if prime_number is not None:
#         print(prime_number, end=" ")

# ----------------------------------------------------------------------------------------------------------------------

# Q.4 Python Program for Fibonacci numbers
# using recursion
# def fib(var):
#     if var == 1:
#         return 0
#     if var == 2:
#         return 1
#     if var > 2:
#         return fib(var - 1) + fib(var - 2)
#
#
# num = int(input('enter the range for fibonacci series :\n'))
# for i in range(1, num + 1):
#     a = fib(i)
#     print(a)
#
# # without using recursion
#
# a, b, c = 0, 0, 0
#
#
# def fibo(var):
#     global a, b, c
#     if var == 0:
#         a = var
#         return a
#     if var == 1:
#         b = var
#         return b
#     if var > 1:
#         c = a + b
#         a = b
#         b = c
#         return b
#
#
# num = int(input('enter the range for fibonacci series :\n'))
# for i in range(num):
#     d = fibo(i)
#     print(d)

# ----------------------------------------------------------------------------------------------------------------------

# Q.5 Python Program to find sum of array (using multiple approach)
# from functools import reduce
#
# lst = [1, 2, 3, 4, 5, 6, 7]
# print(lst)
# print(f'sum of all element in list is : {sum(lst)}')
#
# sum_ = 0
# for i in lst:
#     sum_ += i
# print(f'sum of all element in list is : {sum_}')
#
# total = reduce(lambda a, b: a + b, lst)
# print(f'sum of all element in list is : {total}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.6 Python Program to find the largest element in an array

# from functools import reduce
# lst = [81, 25, 58, 36, 78, 64, 15, 49]
# print(lst)
#
# largest = 0
# for i in lst:
#     if i > largest:
#         largest = i
#
# print(f'The largest number inside list is : {largest}')
#
# largestEle = reduce(lambda a, b: a if a > b else b, lst)
# print(f'The largest number inside list is : {largestEle}')
#
# lst.sort()
# print(f'The largest number inside list is : {lst[-1]}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.7 Python Program for array rotation

# def rotateArr(arr1, diff):
#     arr2 = arr1[diff:] + arr1[:diff]
#     return arr2
#
#
# arr = [81, 25, 58, 36, 78, 64, 15, 49]
# print(f'list before rotation rotation = {arr}')
#
# for i in range(len(arr)):
#     arr = rotateArr(arr, 1)
#     print(f'list after rotation rotation = {arr}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.8 Python Program for Reversal algorithm for array rotation

# def rotateArr(arr1, diff):
#     arr2 = arr1[-diff:] + arr1[:-diff]
#     return arr2
#
#
# arr = [81, 25, 58, 36, 78, 64, 15, 49]
# print(f'list before rotation rotation = {arr}')
#
# for i in range(len(arr)):
#     arr = rotateArr(arr, 1)
#     print(f'list after rotation rotation = {arr}')


# ----------------------------------------------------------------------------------------------------------------------

# Q.9 Python Program to Split the array and add the first part to the end

# lst = [81, 25, 58, 36, 78, 64, 15, 49, 55]
# print(f'list before splitting {lst}')
# length = len(lst)
# half_length = int(length / 2)
#
# lst = lst[half_length:] + lst[:half_length]
# print(f'list after splitting {lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.10 Python Program for Find reminder of array multiplication divided by n
# from functools import reduce
#
#
# def find_remainder(var, n):
#     sum_1 = reduce(lambda x, y: (x % n) * (y % n), var)
#     remainder = sum_1 % n
#     print(remainder)
#
#
# arr = [10, 13, 5, 8, 35, 14]
# num = int(input('enter a number :\n'))
# find_remainder(arr, num)

# ----------------------------------------------------------------------------------------------------------------------

# Q.11 Python program to interchange first and last elements in a list
# lst = [81, 25, 58, 36, 78, 64, 15, 49, 55]
# print(f'list before interchanging its element {lst}')
#
# lst[0], lst[-1] = lst[-1], lst[0]
# print(f'list after interchanging its element {lst}')
#
# num1 = lst.pop(0)
# num2 = lst.pop(-1)
#
# lst.insert(0, num2)
# lst.insert(-1, num1)
# print(f'list after interchanging its element {lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.12 Python program to swap two elements in a list
# lst = [81, 25, 58, 36, 78, 64, 15, 49, 55]
# print(f'list before swapping its element {lst}')
#
# lst[2], lst[4] = lst[4], lst[2]
# print(f'list after swapping its element {lst}')
#
# num1 = lst.pop(4)  # while removing, first pop element having greater index
# num2 = lst.pop(2)
# lst.insert(2, num1)  # while inserting, first insert element having smaller index
# lst.insert(4, num2)
#
# print(f'list after swapping its element {lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.13 Python program to remove Nth occurrence of the given word

# import random
# lst = ['mango', 'apple', 'banana', 'cherry', 'apple', 'watermelon', 'kiwi', 'apple', 'mango', 'cherry']
# word = random.choice(lst)  # randomly select fruit from list
# count = lst.count(word)    # get count of how many times that fruit occur in list
# n = random.randint(1, count)   # select random occurrence of that fruit inside list
#
#
# print(f'list before removing Nth i.e. {n} occurrence of {word} :\n{lst}')
# start_idx = -1
#
#
# def func(var):
#     global start_idx
#     start_idx = lst.index(var, start_idx + 1)
#     return start_idx
#
#
# final_idx = 0
# for i in range(n):   # if we want to remove Nth element then we want to iterate over that list Nth time
#     final_idx = func(word)
# a = lst.pop(final_idx)
# print(f'list after removing Nth i.e. {n} occurrence of {word} :\n{lst}')


# count = 0
# for i in range(len(lst)):
#     if lst[i] == word:
#         count += 1
#     if count == n:
#         lst.pop(i)
#         break
# print(f'list after removing Nth i.e. {n} occurrence of {word} :\n{lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.14 Python | Ways to find length of list

# lst = ['mango', 'apple', 'banana', 'cherry', 'apple', 'watermelon', 'kiwi', 'apple', 'mango', 'cherry']
# print(lst)
#
# print('length of the list is :', len(lst))
#
# count = 0
# for i in lst:
#     count += 1
#
# print('length of the list is :', count)
#
# count_1, final_count = 0, 0
# lst_1 = []
# for fruit in lst:
#     if fruit not in lst_1:
#         lst_1.append(fruit)
#         count_1 = lst.count(fruit)
#         final_count = final_count + count_1
# print('length of the list is :', final_count)

# ----------------------------------------------------------------------------------------------------------------------

# Q.15 Python | Ways to check if element exists in list

# lst = [1, 2, 5, 8, 14, 3, 6, 11]
#
# n = int(input('enter a number :\n'))
# if n in lst:
#     print(f'{n} is present in list')
# else:
#     print(f'{n} is not present in list')
#
# for i in lst:
#     if i != n:
#         continue
#     else:
#         print(f'{n} is present in list')
#         break
# else:
#     print(f'{n} is not present in list')

# ----------------------------------------------------------------------------------------------------------------------

# Q.16 Different ways to clear a list in Python

# lst = [1, 2, 5, 8, 14, 3, 6, 11]
# print(f'list before clearing : {lst}')

# lst.clear()
# print(f'list after clearing : {lst}')

# length = len(lst)
# for i in range(length):
#     lst.pop(-1)
# print(f'list after clearing : {lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.17 Python | Reversing a List Python

# lst = [1, 2, 5, 8, 14, 3, 6, 11]
# print(f'list before reversing {lst}')

# lst.reverse()
# print(f'list after reversing {lst}')

# lst_1 = []
# for i in lst:
#     lst_1.insert(0, i)
# print(f'list after reversing {lst_1}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.18 Cloning or Copying a list Python

# lst = [1, 2, 5, 8, 14, 3, 6, 11]
# print(f'original list = {lst}')
#
# lst_1 = lst
# print(f'copy of list = {lst_1}')
#
# lst_2 = []
# for i in lst:
#     lst_2.append(i)
# print(f'copy of list = {lst_2}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.19 Count occurrences of an element in a list
# lst = ['mango', 'apple', 'banana', 'cherry', 'apple', 'watermelon', 'kiwi', 'apple', 'mango', 'cherry']
# print(lst)
#
# lst1 = []
# for i in lst:
#     if i not in lst1:
#         lst1.append(i)
#
#         print(f'{i} = {lst.count(i)}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.20 Python program to find sum of elements in list
# from functools import reduce
# lst = [12, 54, 16, 98, 67, 34, 85, 24, 71]
# print(lst)
#
# print(f'sum of all element of list is : {sum(lst)}')
#
# total = 0
# for i in lst:
#     total += i
# print(f'sum of all element of list is : {total}')
#
# ans = reduce(lambda a, b: a + b, lst)
# print(f'sum of all element of list is : {ans}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.21 Python | Multiply all numbers in the list
# from functools import reduce
# lst = [2, 4, 6, 8, 7, 3, 8, 4, 1]
# print(lst)
#
# product = 1
# for i in lst:
#     product *= i
# print(f'multiplication of all element of list is : {product}')
#
# product_1 = reduce(lambda a, b: a * b, lst)
# print(f'multiplication of all element of list is : {product_1}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.22 Python program to find the smallest number in a list
# import functools
#
# lst = [35, 98, 16, 75, 89, 62, 43]
# print(lst)
# smallest = lst[0]
# for i in lst:
#     if i < smallest:
#         smallest = i
# print(f'smallest number in the list is {smallest}')
#
# small = functools.reduce(lambda a, b: a if a < b else b, lst)
# print(f'smallest number in the list is {small}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.23 Python program to find the largest number in a list
# import functools
#
# lst = [35, 98, 16, 75, 89, 62, 43]
# print(lst)
# largest = lst[0]
# for i in lst:
#     if i > largest:
#         largest = i
# print(f'largest number in the list is {largest}')
#
# large = functools.reduce(lambda a, b: a if a > b else b, lst)
# print(f'largest number in the list is {large}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.24 Python program to find second-largest number in a list
# from functools import reduce
#
# lst = [35, 98, 16, 75, 89, 62, 43, 99]
# print(lst)
#
# x = reduce(lambda a, b: a if a > b else b, lst)
# y = reduce(lambda a, b: a if b < a else b, list(filter(lambda c: c != x, lst)))
# print(f'the second largest number inside list is {y}')
#
# lst.sort()
# second_largest_ = lst[-2]
# print(f'the second largest number inside list is {second_largest_}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.25 Python program to print even numbers in a list
# lst = [35, 98, 16, 75, 89, 62, 43, 52, 65, 82, 78, 99]
# print(lst)
# even_lst = []
#
# for i in lst:
#     if i % 2 == 0:
#         even_lst.append(i)
# print(f'even numbers from the given list : {even_lst}')
#
# even = list(filter(lambda a: a % 2 == 0, lst))
# print(f'even numbers from the given list : {even}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.26 Python program to print odd numbers in a List

# lst = [35, 98, 16, 75, 89, 62, 43, 52, 65, 82, 78, 99]
# print(lst)
# odd_lst = []
#
# for i in lst:
#     if i % 2 != 0:
#         odd_lst.append(i)
# print(f'odd numbers from the given list : {odd_lst}')
#
# odd = list(filter(lambda a: a % 2 != 0, lst))
# print(f'odd numbers from the given list : {odd}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.27 Python program to print all even numbers in a range

# even_lst = []
# for i in range(10, 30):
#     if i % 2 == 0:
#         even_lst.append(i)
# print(f'even numbers from given range are : {even_lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.28 Python program to print all odd numbers in a range

# odd_lst = []
# for i in range(10, 30):
#     if i % 2 != 0:
#         odd_lst.append(i)
# print(f'odd numbers from given range are : {odd_lst}')
#
# ans = list(filter(lambda a: a if a % 2 != 0 else False, range(10, 30)))
# print(ans)

# ----------------------------------------------------------------------------------------------------------------------

# Q.29 Python program to count Even and Odd numbers in a List

# lst = [35, 98, 16, 75, 89, 62, 43, 52, 65, 82, 78, 99, 100]
# print(lst)
# even_counter, odd_counter = 0, 0
#
# for i in lst:
#     if i % 2 == 0:
#         even_counter += 1
#     else:
#         odd_counter += 1
#
# print(f'total even numbers present in given list are {even_counter}')
# print(f'total odd numbers present in given list are {odd_counter}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.30 Python program to print positive numbers in a list

# lst = [35, 98, -16, 75, 89, 62, -43, 52, 65, -82, -78, 99, 100]
# print(lst)
#
# positive = []
# for i in lst:
#     if i >= 0:
#         positive.append(i)
# print(f'positive numbers from given list are : {positive}')


# positive_nums = list(filter(lambda a: a >= 0, lst))
# print(f'positive numbers from given list are : {positive_nums}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.31 Python program to print negative numbers in a list

# lst = [35, 98, -16, 75, -89, 62, -43, 52, 65, -82, -78, 99, 100]
# print(lst)
#
# negative = []
# for i in lst:
#     if i < 0:
#         negative.append(i)
# print(f'negative numbers from given list are : {negative}')
#
#
# negative_nums = list(filter(lambda a: a < 0, lst))
# print(f'negative numbers from given list are : {negative_nums}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.32 Python program to print all positive numbers in a range

# positive = []
#
# for i in range(-10, 10):
#     if i >= 0:
#         positive.append(i)
# print(f'positive numbers present given range are : {positive}')
#
# positive_numbers = list(filter(lambda a: a >= 0, range(-10, 10)))
# print(f'positive numbers present given range are : {positive_numbers}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.33 Python program to print all negative numbers in a range

# negative = []
#
# for i in range(-10, 10):
#     if i < 0:
#         negative.append(i)
# print(f'negative numbers present given range are : {negative}')
#
# negative_numbers = list(filter(lambda a: a < 0, range(-10, 10)))
# print(f'negative numbers present given range are : {negative_numbers}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.34 Python program to count positive and negative numbers in a list

# positive_counter, negative_counter = 0, 0
# lst = [35, 98, -16, 75, -89, 62, -43, 52, 65, -82, -78, 99, 100]
#
# for i in lst:
#     if i >= 0:
#         positive_counter += 1
#     else:
#         negative_counter += 1
#
# print(f'total positive numbers present in given list are {positive_counter}')
# print(f'total negative numbers present in given list are {negative_counter}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.35 Remove multiple elements from a list in Python

# lst = [35, 98, -16, 75, 98, 62, 35, 52, 65, -16, -78, 75, 100]
# print(lst)

# lst_1 = set(lst)
# lst = list(lst_1)
# print(f'list after removal of all duplicate elements :\n{lst}')

# lst = [35, 98, -16, 75, 98, 62, 35, 52, 65, -16, -78, 75, 100]
# print(lst)
# for i in range(len(lst)-1, -1, -1):
#     if lst.count(lst[i]) > 1:
#         lst.remove(lst[i])
# print(f'list after removal of all duplicate elements :\n{lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.36 Python | Remove empty tuples from a list

# lst = [35, 98, (), 75, 98, (62,), 35, 52, (), -16, (-78, 75), (), 100]
# print(lst)
#
# for i in range(len(lst)-1, -1, -1):
#     if lst[i] == ():
#         lst.pop(i)
#
# print(f'list after removing empty tuple : {lst}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.37 Python | Program to print duplicates from a list of integers

# lst = [35, 98, -16, 75, 98, 62, 35, 52, 65, 98, -78, 75, 100, 52]
# print(lst)
#
# lst_1 = []
# for i in lst:
#     if lst.count(i) > 1 and i not in lst_1:
#         lst_1.append(i)
# print(lst_1)

# ----------------------------------------------------------------------------------------------------------------------
# Q.38 Python program to find Cumulative sum of a list Break a list into chunks of size N in
# ----------------------------------------------------------------------------------------------------------------------

# Q.39 Python | Sort the values of first list using second list

# lst_1 = ['c', 'j', 'b', 'h', 'n', 'q', 'p', 'o', 'r', 'l']
# print(f'first list :\n{lst_1}')
# lst_2 = [5, 8, 9, 2, 13, 5, 21, 3, 7, 11]
# print(f'second list :\n{lst_2}')
#
# zipped_list = list(zip(lst_1, lst_2))
# print(f'zipped list :\n{zipped_list}')
#
# sorted_list = sorted(zipped_list, key=lambda a: (a[1], a[0]))
# print(f'sorted list based on second list :\n{sorted_list}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.40 Python program to check if a string is palindrome or not Reverse words

# string = input('enter a string :\n')
#
# if string == string[::-1]:
#     print('given string is palindrome')
# else:
#     print('given string is not palindrome')

# ----------------------------------------------------------------------------------------------------------------------

# Q.41 Python Ways to remove i’th character from string
# import random
# string = input('enter a string:\n')
#
# i = random.randint(0, len(string))
# print(f'value of index from which we want to remove the character :\n{i}')
#
# new_string = string[:i] + string[i+1:]
# print(f'string after removing ith character :\n{new_string}')

# new_string_2 = ''
# for char in range(len(string)):
#     if char != i:
#         new_string_2 = new_string_2 + string[char]
#
# print(f'string after removing ith character :\n{new_string_2}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.42 Python | Check if a Substring is Present in a Given String

# string = "good morning team brainworks!"
# sub_string = input('enter the string :\n')
#
# if sub_string in string:
#     print('entered string is substring of given string.')
# else:
#     print('entered string is not a substring of given string.')

# ----------------------------------------------------------------------------------------------------------------------

# Q. Find length of a string in python (4 ways)

# string = "good morning team brainworks!"
# print(string)

# length = len(string)
# print(f'length of a given string is {len(string)}')

# count = 0
# for i in string:
#     count += 1
# print(f'length of a given string is {count}')

# lst = []
# count1 = 0
# for i in string:
#     if i not in lst:
#         lst.append(i)
#         count1 = count1 + string.count(i)
# print(f'length of a given string is {count1}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.43 Python program to print even length words in a string

# string = input('enter a string :\n')
# str_lst = string.split()
# for word in str_lst:
#     lenth = len(word)
#     if lenth % 2 == 0:
#         print(word, end=', ')


# even_word = list(filter(lambda a: a if len(a) % 2 else False, str_lst))
# print(even_word)

# ----------------------------------------------------------------------------------------------------------------------

# Q.44 Program to accept the strings which contains all vowels

# string = input('enter a string :\n')
# string_1 = string.replace(' ', '')
# string_1 = string_1.lower()

# vowels = [string_1.count('a'), string_1.count('e'), string_1.count('i'), string_1.count('o'), string_1.count('u')]
#
# if vowels.count(0) > 0 :
#     print('string does not contains all vowels in it.')
# else:
#     print('string contains all vowels in it.')

# --------------------------------
# string = input('enter a string :\n')
# string_1 = string.replace(' ', '')
# string_1 = string_1.lower()

# vowels_set = {'a', 'e', 'i', 'o', 'u'}
# string_set = set(string_1)
#
# final_res = vowels_set.issubset(string_set)
# if final_res:
#     print('string contains all vowels in it.')
# else:
#     print('string does not contains all vowels in it.')

# ----------------------------------------------------------------------------------------------------------------------

# Q.45 Count the Number of matching characters in a pair of string

# string_1 = input('enter a string :\n')
# string_2 = input('enter a another string :\n')
#
# string_1 = set(string_1.replace(' ', '').lower())
# string_2 = set(string_2.replace(' ', '').lower())

# final_res = string_1.intersection(string_2)
# print(f'matched characters are : {final_res}')


# --------------------------------------

# string_1 = input('enter a string :\n')
# string_2 = input('enter a another string :\n')
#
# string_1 = set(string_1.replace(' ', '').lower())
# string_2 = list(string_2.replace(' ', '').lower())
#
# final_res = set(filter(lambda a: a if a in string_1 else False, string_2))
# print(f'matched characters are : {final_res}')

# ----------------------------------------------------------------------------------------------------------------------

# Q.46 Python program to count number of vowels using sets in given string Remove all duplicates from a given string
# in Python







































