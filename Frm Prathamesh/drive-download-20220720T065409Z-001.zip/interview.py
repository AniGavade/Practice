# def outer(var):
#     def inner(x):
#         a = x.upper()
#         ans = var(a)
#         print(ans)
#     return inner
#
#
# @outer
# def mainFunc(a):
#     return (f'{a} good morning')
#
# mainFunc("hello")



# class Animal:
#     def run(self):
#         print('dog can run')


# class Animal1(Animal):
#     def bark(self):
#         print("dog can bark")

# a = Animal1()
# a.run()
# a.bark()


# class Animal2(Animal):
#     def sit(self):
#         print('dog can sit')
# # b = Animal2()
# # b.run()
# # b.sit()
#
#
# class Animal3(Animal2):
#     def rollOver(self):
#         print('dog can roll over')
#
# c = Animal3()
# c.run()
# c.sit()
# c.rollOver()

