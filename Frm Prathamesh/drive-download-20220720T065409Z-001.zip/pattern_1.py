
# number = int(input("Enter number of rows :"))
# for i in range(number):
#     for j in range(i+1):
#         print("*", end=" ")
#     print()

# number_1 = int(input("Enter number of rows :"))
# for i in range(number_1, 0, -1):
#     for j in range(i):
#         print("*", end=" ")
#     print()

# number_2 = int(input("Enter number of rows :"))
# k = 1
# for i in range(number_2):
#     for j in range(k):
#         print("*", end=" ")
#     k = k + 2
#     print()
#
# number_3 = int(input("Enter number of rows :"))
# k = (number_3 * 2) - 1
# for i in range(number_3,0,-1):
#     for j in range(k):
#         print("*",end=" ")
#     k = k - 2
#     print()
#
# number_4 = int(input("Enter the number of rows :"))
# k = number_4
# for i in range(number_4):
#     for j in range(k-1):
#         print(end=" ")
#     for j in range(i + 1):
#         print("*", end=" ")
#     k = k - 1
#     print()


number_4 = int(input("Enter the number of rows :"))
k = number_4
for i in range(number_4):
    for j in range(k-1):
        print(end=" ")
    for j in range(i + 1):
        print("*", end=" ")
    k = k - 1
    print()


