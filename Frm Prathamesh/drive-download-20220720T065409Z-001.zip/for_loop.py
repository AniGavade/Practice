# l1 = [1,2,5,4,3,2,1,9,8,3,6,4,7,9,1,4,2,6,7,8,9,3,5,4,2,1,6,8,7,9]
# l = len(l1)
#
# print(l1.index(5))

l1 = [i*i for i in range(100) if i % 5 == 0]
print(l1)

# for i in range(l):
#     print(i)
# print()
# for i in l1:
#     print(i)

# print()
# for i in l1:
#     print(l1[i])
# for i in l1:
#     print(i)

# tup = tuple(l1)
# l = len(tup)
# for i in range(l):
#     print(i)
# print()
# for i in range(l):
#     print(tup[i])

# sum1 = sum(l1[2:6])
# print(sum1)