# clearing list

# list_1 = [1,2,3,4,5,6,7,8,9]
# print(list_1)

# list_1.clear()
# print("====================================================")
# list_1 = []
# print("====================================================")
# for i in range(len(list_1)):
#     list_1.pop()
# print("====================================================")
# list_1 *= 0
# print("====================================================")
# del list_1[:]
# print("====================================================")
# print(list_1)

# Program to multiply all numbers in list

# length = len(list_1)
# product = 1
# for i in range(length):
#     product *= list_1[i]
# print(product)
# print("====================================================")

# Program to multiply two lists

# list_2 = [2,4,3,1]
# list_3 = [4,3,5,7]
# list_4 = []
# for i in range(len(list_2)):
#     list_4.append(list_2[i] * list_3[i])
# print("====================================================")
# list_4 = [list_2[i] * list_3[i] for i in range(len(list_2))]
# print(list_4)

# Program to find second-largest element from list

# list_5 = [56,87,21,69,87,98,98]
# print(list_5)
# max_ele = max(list_5)
# while max_ele == max(list_5):
#     list_5.remove(max(list_5))
# print("second-largest element in list is : ",max(list_5))
# print("====================================================")
# list_5 = [56,87,21,69,87,98,98,98]
# print(list_5)
# a = list_5.count(max(list_5))
# list_5.sort()
# for i in range(a):
#     list_5.pop()
# print("second-largest element in list is : ",list_5[-1])
# print("====================================================")

# Python program to find N-largest elements from a list

# list_6 = [48, 36, 47, 98, 32, 45, 68, 75]
# list_7 = []
# print(list_6)
# print("Enter the value of N : ")
# n = int(input())
# for i in range(n):
#     list_6.sort()
#     list_7.append(list_6.pop())
# print(list_7)
# print("===============================================================")
# list_6 = [48, 36, 47, 98, 32, 45, 68, 75]
# list_6.sort()
# print("Enter the value of N : ")
# n = int(input())
# print(list_6[-n:])
# list_7 = list_6[-n:]
# list_7.reverse()
# print(list_7)
# print("===============================================================")

# Program to print all even no from list
# list_8 = [2,9,5,65,47,88,54,21,12,23,36,55,74]
# list_9 = []
# for i in range(len(list_8)):
#     if (list_8[i] % 2 == 0):
#         list_9.append(list_8[i])
# print(list_9)

# print("===============================================================")

# Program to print all even no from range

# list_10 = []
# for i in range(50):
#     if i % 2 == 0:
#         list_10.append(i)
# print(list_10)

# print("===============================================================")

# Print all odd no from a list
# list_11 = [2,9,5,65,47,88,54,21,12,23,36,55,74]
# list_12 = []
# for i in range(len(list_11)):
#     if list_11[i] % 2 != 0:
#         list_12.append(list_11[i])
# print(list_12)

# print("===============================================================")

# Program to print all odd no from range
# list_13 = []
# for i in range(50):
#     if i % 2 != 0:
#         list_13.append(i)
# print(list_13)

# print("===============================================================")

# Program to find all positive numbers from list
# list_14 = [14,25,-54,-89,65,87,-45,-25,41,69,-98,12,-14,-45,84,0]
# list_15 = []
# for i in range(len(list_14)):
#     if list_14[i] < 0 :
#         list_15.append(list_14[i])
# print(list_15)

# print("===============================================================")

# # Program to find all negative numbers from list
# list_16 = [14,25,-54,-89,65,87,-45,-25,41,69,-98,12,-14,-45,84,0]
# list_17 = []
# for i in range(len(list_16)):
#     if list_16[i] >= 0:
#         list_17.append(list_16[i])
# print(list_17)

# print("===============================================================")