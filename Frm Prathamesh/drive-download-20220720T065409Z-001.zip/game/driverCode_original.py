import random

deck = []
suits = ["S", "H", "C", "D"]  # s = spades,h=hearts,c=clubs,d=hearts
vals = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]


def CreateDeck():
    for suit in suits:
        for val in vals:
            item = suit + val
            deck.append(item)

    return deck


full_suit = CreateDeck()
print(full_suit)


def cardShuffle(fullSuit):
    for i in range(len(fullSuit)):
        def shuffled_suit(var):
            random_card = random.choice(var)
            return random_card

        returned = shuffled_suit(fullSuit)

        temp = fullSuit[i]
        idx = fullSuit.index(returned)
        fullSuit[i] = fullSuit[idx]
        fullSuit[idx] = temp
    return fullSuit


full_suit = cardShuffle(full_suit)

print(full_suit)

shuffled = full_suit.copy()
# print(shuffled)

player_1 = []
player_2 = []
player_3 = []
player_4 = []
usedCard = []

num_card = int(input("How many cards do you want to give each player :\n"))

while len(shuffled) > (52 - (num_card * 4)):

    if len(shuffled) % 4 == 0:
        card_to_distribute = shuffled.pop(0)
        player_1.append(card_to_distribute)
    elif len(shuffled) % 4 == 3:
        card_to_distribute = shuffled.pop(0)
        player_2.append(card_to_distribute)
    elif len(shuffled) % 4 == 2:
        card_to_distribute = shuffled.pop(0)
        player_3.append(card_to_distribute)
    elif len(shuffled) % 4 == 1:
        card_to_distribute = shuffled.pop(0)
        player_4.append(card_to_distribute)

print(player_1)
print(player_2)
print(player_3)
print(player_4)

print()
print("Player 1 now its your turn.")
print()

counter = 1
choice = 2      # at start of the game choice is set to zero so that player_1 can always append new card for first time
discarded_card = ""


def gameFlow(player, shuffled):
    global counter
    global choice
    global discarded_card
    if len(shuffled) == 0:
        shuffled = cardShuffle(usedCard)

    new_card = shuffled.pop()
    if choice == 1:
        player.append(discarded_card)
    elif choice == 2:
        player.append(new_card)
        usedCard.append(discarded_card)

    def matchedPair(var):
        global flag
        for x in range(len(var)):
            for j in range(len(var)):
                if var[x][1] == var[j][1] and x != j:        # [1] represent second character on card for matching
                    match1 = var.pop(j)
                    var.insert(0, match1)
                    match2 = var.pop(x)
                    var.insert(0, match2)

                    if var[0][1] == var[1][1] and var[2][1] == var[3][1] and var[4][1] == var[5][1]:
                        flag = 1
        return var

    sequence = matchedPair(player)
    print(sequence)
    # print(player)
    print()


def gameFlow2(player, next_player, player_no):
    global counter
    global choice
    global discarded_card
    discarded_card = input("Which card do you want to discard from your cards :\n").upper()
    player.remove(discarded_card)

    counter += 1

    print(discarded_card)
    print()
    print(f"Player {player_no} now its your turn.")
    print()
    print(next_player)
    print()
    choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))
    return player


while True:
    if counter % 4 == 1:
        flag = 0
        gameFlow(player_1, shuffled)
        if flag == 1:
            print('Congratulations Player_1 ! You have won the game.')
            break
        player_1 = gameFlow2(player_1, player_2, 2)

    elif counter % 4 == 2:
        flag = 0
        gameFlow(player_2, shuffled)
        if flag == 1:
            print('Congratulations Player_2 ! You have won the game.')
            break
        player_2 = gameFlow2(player_2, player_3, 3)

    elif counter % 4 == 3:
        flag = 0
        gameFlow(player_3, shuffled)
        if flag == 1:
            print('Congratulations Player_3 ! You have won the game.')
            break
        player_3 = gameFlow2(player_3, player_4, 4)

    elif counter % 4 == 0:
        flag = 0
        gameFlow(player_4, shuffled)
        if flag == 1:
            print('Congratulations Player_4 ! You have won the game.')
            break
        player_4 = gameFlow2(player_4, player_1, 1)
