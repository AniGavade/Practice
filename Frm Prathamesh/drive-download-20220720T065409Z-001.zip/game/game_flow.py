from card_distribution import usedCard
from deck_creation_and_card_shuffling import cardShuffle


counter = 1
choice = 2      # at start of the game choice is set to zero so that player_1 can always append new card for first time
discarded_card = ""
flag = 0


def gameFlow(player, shuffled_cards):
    global counter
    global choice
    global discarded_card
    if len(shuffled_cards) == 0:
        shuffled_cards = cardShuffle(usedCard)

    new_card = shuffled_cards.pop()
    if choice == 1:
        player.append(discarded_card)
    elif choice == 2:
        player.append(new_card)
        usedCard.append(discarded_card)

    def matchedPair(var):
        global flag
        for x in range(len(var)):
            for j in range(len(var)):
                if var[x][1] == var[j][1] and x != j:        # [1] represent second character on card for matching
                    match1 = var.pop(j)
                    var.insert(0, match1)
                    match2 = var.pop(x)
                    var.insert(0, match2)

                    if var[0][1] == var[1][1] and var[2][1] == var[3][1] and var[4][1] == var[5][1]:
                        flag = 1
        return var, flag

    sequence, flag = matchedPair(player)
    print(sequence)
    # print(player)
    print()


def gameFlow2(player, next_player, player_no):
    global counter
    global choice
    global discarded_card
    discarded_card = input("Which card do you want to discard from your cards :\n").upper()
    player.remove(discarded_card)

    counter += 1

    print(discarded_card)
    print()
    print(f"Player {player_no} now its your turn.")
    print()
    print(next_player)
    print()
    choice = int(input(f"Type 1 to get {discarded_card} else type 2 to get new card :\n"))
    return player
