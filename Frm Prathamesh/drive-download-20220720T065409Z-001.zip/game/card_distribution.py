from deck_creation_and_card_shuffling import cardShuffle, createDeck

player_1 = []
player_2 = []
player_3 = []
player_4 = []
usedCard = []

plain_full_suit = createDeck()
print(plain_full_suit)

full_suit = cardShuffle(plain_full_suit)
print(full_suit)

shuffled = full_suit.copy()
print(shuffled)


def cardDistribution():
    num_card = int(input("How many cards do you want to give each player :\n"))
    while len(shuffled) > (52 - (num_card * 4)):

        if len(shuffled) % 4 == 0:
            card_to_distribute = shuffled.pop(0)
            player_1.append(card_to_distribute)
        elif len(shuffled) % 4 == 3:
            card_to_distribute = shuffled.pop(0)
            player_2.append(card_to_distribute)
        elif len(shuffled) % 4 == 2:
            card_to_distribute = shuffled.pop(0)
            player_3.append(card_to_distribute)
        elif len(shuffled) % 4 == 1:
            card_to_distribute = shuffled.pop(0)
            player_4.append(card_to_distribute)


cardDistribution()
