import random
deck = []
suits = ["S", "H", "C", "D"]  # s = spades,h=hearts,c=clubs,d=hearts
vals = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]


def createDeck():
    for suit in suits:
        for val in vals:
            item = suit + val
            deck.append(item)
    return deck


def cardShuffle(fullSuit):
    for i in range(len(fullSuit)):
        def shuffled_suit(var):
            random_card = random.choice(var)
            return random_card

        returned = shuffled_suit(fullSuit)

        temp = fullSuit[i]
        idx = fullSuit.index(returned)
        fullSuit[i] = fullSuit[idx]
        fullSuit[idx] = temp
    return fullSuit
