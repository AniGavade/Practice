import game_flow as gf
import card_distribution as cd

print()
print("Player 1 now its your turn.")
print()
print(cd.player_1)

while True:
    if gf.counter % 4 == 1:
        gf.gameFlow(cd.player_1, cd.shuffled)
        if gf.flag == 1:
            print()
            break
        cd.player_1 = gf.gameFlow2(cd.player_1, cd.player_2, 2)

    elif gf.counter % 4 == 2:
        gf.gameFlow(cd.player_2, cd.shuffled)
        if gf.flag == 1:
            break
        cd.player_2 = gf.gameFlow2(cd.player_2, cd.player_3, 3)

    elif gf.counter % 4 == 3:
        gf.gameFlow(cd.player_3, cd.shuffled)
        if gf.flag == 1:
            break
        cd.player_3 = gf.gameFlow2(cd.player_3, cd.player_4, 4)

    elif gf.counter % 4 == 0:
        gf.gameFlow(cd.player_4, cd.shuffled)
        if gf.flag == 1:
            break
        cd.player_4 = gf.gameFlow2(cd.player_4, cd.player_1, 1)
