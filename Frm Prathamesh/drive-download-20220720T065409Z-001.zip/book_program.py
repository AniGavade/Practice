# year = int(input("enter the year :"))
# month = int(input("enter the month :"))
# day = int(input("enter the day :"))
#
# print(f"your current date is {year}-{month}-{day}")
#
# if month == 12 and day == 31:
#     year = year + 1
#     month = 1
#     day = 1
# elif day == 30 and ( month == 4 or month == 6 or month == 9 or month == 11 ):
#     month = month + 1
#     day = 1
# elif day == 31 and ( month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 ):
#     month = month + 1
#     day = 1
# elif year % 400 == 0 or (year % 4 == 0 and year % 100 != 0):
#     if day == 29 and month == 2:
#         month = month + 1
#         day = 1
# elif day == 28 and month == 2:
#         month = month + 1
#         day = 1
# elif day >= 1:
#     day = day + 1
#
# print(f"your next date is {year}-{month}-{day}")
# =======================================================================================

# flag = True
# x1,x2,y1,y2 = 0,0,0,0
# temp1, temp2 = 0,0
# perimeter = 0
# while True:
#     x = input("Enter the x co-ordinates: ")
#     if x != " ":
#         x1 = int(x)
#         y1 = int(input("Enter the y co-ordinates: "))
#         temp1, temp2 = x1, y1
#         x2 = int(input("Enter the x co-ordinates: "))
#         y2 = int(input("Enter the y co-ordinates: "))
#         perimeter = perimeter + ((x1-x2)**2 + (y1-y2)**2)**(1/2)
#         x1 = x2
#         y1 = y2
#     else:
#         break
# perimeter = perimeter + ((x2-temp1)**2 + (y2-temp2)**2)**(1/2)
# print(perimeter)
# =======================================================================================
# Total sublist in list
# lst =[1,2,3,4,5,6,9,7,8,4,5]
# lst_1 = []
#
# for i in range(len(lst)):
#     for j in range(len(lst)+1):
#         p = lst[i:j]
#         if p not in lst_1:
#             lst_1.append(p)
# for i in range(len(lst_1)):
#     print(lst_1[i])
# =======================================================================================
# to check given list is present in original list or not
# l1 = [1, 2, 3, 1, 2, 3, 4, 5, 6]
# l2 = [4, 5, 6]
# print(l1)
# print(l2)
# x = len(l2)
# for i in range(len(l1)):
#     if l1[i:x] == l2:
#         print("yes")
#         break
#     x = x + 1
# else:
#     print("no")
# =======================================================================================
# # problem 80
# import random
#
# l = ['H', 'T']
#
# lst = []
# total_count = 0
# for i in range(10):
#     count = 0
#     while True:
#         output = random.choice(l)
#
#         lst.append(output)
#         count += 1
#
#         if len(lst) > 2 and (lst[-1] == lst[-2] == lst[-3]):
#             break
#     print(lst, f"( {count} flips )")
#     total_count = total_count + count
#     lst.clear()
#     print()
# average = total_count / 10
# print(f"on average, {average} flips were needed.")
# =======================================================================================
# # decimal to binary conversion
# lst = []  # creating empty list
#
#
# def decTobin(var):
#     while var > 0:   # loop will run until num becomes 0 by dividing it by 2
#         if var % 2 == 0:
#             lst.append(0)  # when num is perfectly divisible by 2 then 0 is appended to lst
#             # else 1 is appended to lst
#         else:
#             lst.append(1)
#         var = int(var / 2)
#
#
# num = int(input("enter the number whose binary number you want: "))
# decTobin(num)
# lst1 = lst[::-1]    # reversing list
# print(f"binary form of {num} is :", end=' ')
# for i in lst1:
#     print(i, end=' ')
# print()
#
# # binary to decimal
# string = [str(i) for i in lst1]    # converting int items of list into str items
# str_integer = "".join(string)      # joining the list to get single string
# integer = int(str_integer)         # converting string into integer
#
# decNum = 0
#
#
# def binToDec(var):
#     global decNum
#     count = 0
#     while var > 0:
#         last_num = var % 10       # when any number is divided by 10 using modulo it gives us last digit of a number
#         var = int(var / 10)       # dividing number by 10 converting it into int and reassigned it back to same variable
#         if last_num == 1:
#             decNum = decNum + 2 ** count    # if digit is 1 then we're adding the 2's power to its corresponding
#             # position (position of that digit from right side inside that binary number)
#         count += 1   # count variable is used to track position of digits from right side
#
#
# binToDec(integer)
#
# print(f"the decimal to binary conversion of {integer} is :", decNum)
# =======================================================================================
# # Exercise 79: Maximum Integer
# import random
#
# max_num = 0
# count = 0
# for i in range(1, 100):
#     # print(i)
#     num = random.choice(range(1, 101))
#     if num > max_num:
#         if max_num != 0:
#             print(num, "<== Update")
#             count += 1
#         else:
#             print(num)
#         max_num = num
#     else:
#         print(num)
#
# print(f"The maximum value found is {max_num}.")
# print(f"The maximum value updated {count} times.")
# =======================================================================================
# Exercise 130 : Text editor
#
dict_1 = {'1': [',', '.', '?', '!', ':'], '2': ['A', 'B', 'C'], '3': ['D', 'E', 'F'], '4': ['G', 'H', 'I'],
          '5': ['J', 'K', 'L'], '6': ['M', 'N', 'O'], '7': ['P', 'Q', 'R', 'S'], '8': ['T', 'U', 'V'],
          '9': ['W', 'X', 'Y', 'Z'], '0': [' ']}

string = input('please enter a string :')


def func(var):
    for i in dict_1:
        var = var.upper()
        # print(i)
        if var in dict_1[i]:
            key_impression = dict_1[i].index(var) + 1
            # if i == 0:
                # var = "SPACE"
            new_num = key_impression * str(i)
            # print(new_num)
            # print(f'number of times key number should pressed for character {var} is :', key_impression)
            # print(f'keypad number should pressed for {var} is :', i)
            return new_num


final_result = list(map(func, string))
final_result = ''.join(final_result)

print(final_result)
