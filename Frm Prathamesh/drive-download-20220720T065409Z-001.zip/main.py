# class Dog:
#     def bark(self):
#         print("dog barking")
#
#
# d = Dog()
# Dog.bark(d)

# ----------------------------------------------------------------------------------------------------------------------

# class Man:
#     gender = "male"
#
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age
#         # print('class Man')
#
#     def speak(self, language='marathi'):
#         self.language = language
#         print(f"{self.name} speaks {self.language} very well.")
#
#     def old(self):
#         if self.gender == 'male':
#             pronoun = 'he'
#         else:
#             pronoun = 'she'
#         print(f'{pronoun} is {self.age} years old.')
#         print(f'gender is {self.gender}')
#
#
# m = Man("shubham", 30)
# m.speak("English")
# m.old()
#
# m2 = Man('neha', 25)
# m2.gender = 'female'
# m2.speak()
# m2.old()

# ----------------------------------------------------------------------------------------------------------------------

# class Car:
#     def __init__(self, name, model, year):
#         self.name = name
#         self.model = model
#         self.year = year
#         # default argument
#         self.mileage = 0
#
#     def describe_car(self):
#         desc = f'{self.name} {self.model} {self.year}'
#         self.desc = desc.title()
#         print('This is', self.desc)
#
#     def update_mileage(self, mileage):
#         if self.mileage < mileage:
#             self.mileage = mileage
#         else:
#             print('you cannot roll back mileage.')
#
#         print(f'new mileage of {self.desc} is {self.mileage}.')
#
#     def incremental_update(self, increment):
#         self.mileage += increment
#         print(f'new mileage of {self.desc} is {self.mileage}.')
#
# c = Car('Honda', 'city', 2008)
# c.describe_car()
# c.update_mileage(12)
# c.update_mileage(10)
# c.incremental_update(2)

# ----------------------------------------------------------------------------------------------------------------------

class Employee:
    raise_percent = 1
    no_of_employee = 0

    def __init__(self, name, last, salary):
        self.name = name
        self.last = last
        self.salary = salary
        self.email = f'{self.name}.{self.last}{(len(name))}@gmail.com'

    def get_details(self):
        print(f'{self.name} {self.last}')
        print(self.email)
        print(f'{self.name}\'s salary is {self.salary}')

    def raise_amount(self):
        raise_amount = int(self.salary * self.raise_percent)
        print(f'raised salary for {self.name} is {raise_amount}')

    @classmethod
    def raise_percentage(cls, percentage):
        cls.raise_percent = percentage

    # class method as a constructor
    @classmethod
    def from_srting(cls, string):
        name, last, salary = string.split('-')
        return cls(name, last, salary)


e1 = Employee('prathamesh','sawant',150000)
e2 = Employee('uday', 'sarode', 150000)
# e1.get_details()
# e2.get_details()
#
# Employee.raise_percent = 1.03
# e1.raise_amount()
# e2.raise_amount()
#
# e1.raise_percent = 1.08
# e1.raise_amount()
# e2.raise_amount()
#
# Employee.raise_percent = 1.04
# e1.raise_amount()
# e2.raise_amount()
#
# Employee.raise_percentage(1.09)
# e1.raise_amount()
# e2.raise_amount()

# emp1_str = 'paresh-patil-100000'
# emp2_str = 'aniruddha-gavade-110000'
#
# emp1 = Employee.from_srting(emp1_str)
# emp2 = Employee.from_srting(emp2_str)
#
# emp1.get_details()
# emp2.get_details()
