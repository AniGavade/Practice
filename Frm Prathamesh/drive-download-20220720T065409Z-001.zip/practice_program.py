# 1. Write a Python program to find those numbers which are divisible by 7 and multiple of 5, between 1500 and 2700 (both included).
# list_1 = []
# for i in range(1500,2701):
#     if i % 5 == 0 and i % 7 == 0:
#         list_1.append(i)
# print(list_1)

# print("=========================================================================================")

# 3. Write a Python program to guess a number between 1 to 9.
# import random
# random_number = random.randint(1,10)
# number_to_be_guess = 0
# while number_to_be_guess != random_number:
#         number_to_be_guess = int(input("Enter number between 1 to 9 :"))
#         if number_to_be_guess == random_number:
#             print("Bingo ! You have guess number.")
#         else:
#             print("Sorry you have guess wrong number..! Please choose another number.")

# print("=========================================================================================")

# 4. Write a Python program to construct the following pattern, using a nested for loop.
#
#       *
#       * *
#       * * *
#       * * * *
#       * * * * *
#       * * * *
#       * * *
#       * *
#       *

# l,k=4,5
# m = l
# for i in range(k):
#     for j in range(i + 1):
#         print("*",end=" ")
#     print()
# for i in range(l):
#     for j in range(m):
#         print("*",end=" ")
#     m -= 1
#     print()

# print("=========================================================================================")

# 5. Write a Python program that accepts a word from the user and reverse it.

# word_copy =''
# word = input("Enter a word to reverse it : ")
# for i in range(len(word)):
#     word_copy += word[len(word)-1-i]
# print(word_copy)

# print("=========================================================================================")

# 6. Write a Python program to count the number of even and odd numbers from a series of numbers.

# list_1 = [1,2,3,4,5,6,7,8,9,6,5,8,4,7,2,3,4,5,6,1,5,4,3,4,6]
# length=len(list_1)
# print("Total numbers in list are :",length)
# counter_1, counter_2 = 0, 0
# for i in range(length):
#     if list_1[i] % 2 == 0 :
#         counter_1 += 1
#     elif list_1[i] % 2 != 0 :
#         counter_2 += 1
# print("Number of even numbers =",counter_1)
# print("Number of odd numbers =",counter_2)

# print("=========================================================================================")

# 7. Write a Python program that prints each item and its corresponding type from the following list.

# datalist = [1452, 11.23, 1+2j, True, 'w3resource', (0, -1), [5, 12], {"class":'V', "section":'A'}]
# for i in range(len(datalist)):
#     print("The type of",datalist[i],"is",type(datalist[i]))

# print("=========================================================================================")

# 8. Write a Python program that prints all the numbers from 0 to 6 except 3 and 6.

# for i in range(0,7):
#     if i == 3 or i == 6:
#         continue
#     else:
#         print(i,end=" ")

# print("=========================================================================================")

# 9. Write a Python program to get the Fibonacci series between 0 to 50.

# print("Fibonacci series between 0 to 50,")
# a,b = 0,1
# print(a,end=" ")
# print(b,end=" ")
# for i in range(50):
#     c = a + b
#     if c < 50:
#         print(c, end=" ")
#     a = b
#     b = c

# print("=========================================================================================")

# 10. Write a Python program which iterates the integers from 1 to 50.
# For multiples of three print "Fizz" instead of the number and for the multiples of five print "Buzz".
# For numbers which are multiples of both three and five print "FizzBuzz".

# for i in range(1,51):
#     if i % 3 == 0 and i % 5 == 0:
#         print("FizzBuzz",end=" ")
#     elif i % 5 == 0:
#         print("Buzz",end=" ")
#     elif i % 3 == 0:
#         print("Fizz",end=" ")
#     else:
#         print(i,end=" ")

# print("=========================================================================================")

# 11. Write a Python program which takes two digits m (row) and n (column) as input and generates a two-dimensional array.
# The element value in the i-th row and j-th column of the array should be i*j.

# row = int(input("Enter the value of row :"))
# column = int(input("Enter the value of column :"))
# output = []
# for i in range(row):
#     output_1 = []
#     for j in range(column):
#         k = i * j
#         output_1.append(k)
#     output.append(output_1)
# print("Two dimensional array of",row,"rows and",column,"columns is :",output)

# print("=========================================================================================")

# 12. Write a Python program that accepts a sequence of lines (blank line to terminate) as input and prints the lines as output
# (all characters in lower case).

# lines = []
# while True:
#     line = input("Enter a string :")
#     if line:
#         lines.append(line.lower())
#     else:
#         break
# for i in lines:
#     print(i)

# print("=========================================================================================")

# 13. Write a Python program which accepts a sequence of comma separated 4 digit binary numbers as its input
# and print the numbers that are divisible by 5 in a comma separated sequence.

# list_1 = []
# list_2 = [i for i in input("Enter the binary numbers :").split(',')]
#
# for i in list_2:
#     a = int(i,2)    # converting binary number into interger. for that we need to provide binary number and base_index
#                     # and binary value (here i) should be in string format and base-index is 2
#     if a % 5 == 0:
#         list_1.append(i)
# print(','.join(list_1))     # (',').join(list_name) ==> will provide list elements in comma separated manner

# print("=========================================================================================")

fruits = {"kiwi", "grapes", "apple", "banana", "cherry", "watermelon", "mango"}
fruits.pop()
print(fruits)