l1 = [2,3,4,5,6,7,8,9]
print(l1)
num = int(input("Enter a number : "))
for i in l1:
    if i == num:
        print("number exist :")
        break
else:
    print("number not exist  ")