# WAP to check whether string is palindrome or symmetric
# str = input('Enter a string to check whether it is palindrome or symmetric:')   # ma d am
# half = int(len(str) / 2)
#
# if len(str) % 2 == 0:
#     lstr = str[:half]
#     print(lstr)
#     rstr = str[half:]
#     print(rstr)
# else:
#     lstr = str[:half]
#     rstr = str[half+1:]
# revstr = rstr[::-1]
# print(revstr)
# if lstr == revstr:
#     print(str,"string is palindrome")
# else:
#     print(str,"string is not palindrome.")
#
# if lstr == rstr:
#     print(str,"string is symmetric")
# else:
#     print(str, "string is not symmetric")
print("=================================================================================================================")
# WAP a program to reverse string
# str = input("Enter a string :")
# rev_str = ""
# for i in range(len(str)):
#     rev_str = rev_str + str[-(i+1)]
# print(rev_str)
print("=================================================================================================================")
# Reverse words in a given String in Python
# str = input("Enter a string :")
# lst = str.split(' ')
# lst1 = []
# for i in range(len(lst)):
#     lst1.append(lst[-(i+1)])
# rev_str = (' ').join(lst1)
# print(rev_str)
print("=================================================================================================================")
# Ways to remove i’th character from string in Python
# str1 = 'abcdefghijklmnopqrstuvwxyz'
# new_str = ''
# pos_no = int(input('Enter a position number from which you want remove character from string :\n'))
# index_no = pos_no - 1
# for i in range(len(str1)):
#     if i != index_no:
#         new_str += str1[i]
# print(new_str)
#
# new_str = str1[  :index_no] + str1[index_no+1 : ]
# print(new_str)
print("=================================================================================================================")
# find length of the string
# str1 = input("Enter a string to find its length :")
# counter = 0
# for i in range(len(str1)):
#     counter += 1
# print("length of the given string is",counter)
#
# counter1,counter2 = 0,0
# while(str1[counter1:]):
#     counter2 += counter2
#     counter1 += 1
# print("length of the given string is",counter1)
print("=================================================================================================================")
# Python – Avoid Spaces in string length
# import re
# str1 = "ab cd ef    gh ij kl mn    b"
# str2 = str1.split(' ')
# str3 = []
# print(str2)
# for i in range(len(str2)):
#     if str2[i] != ' ':
#         str3.append(str2[i])
# str4 = ('').join(str3)
# print(str4)
# print("length of string without white spaces is :",len(str4))
#
# str5 = re.sub('\s+','',str1)
# print(str5)
# print("length of string without white spaces is :",len(str5))
print("=================================================================================================================")
# Python program to find even length words in a string and print them.
# str1 = 'hello people how is your study going on'
# lst = str1.split(' ')
# even_count = 0
# for i in range(len(lst)):
#     if len(lst[i]) % 2 == 0:
#         print(lst[i])
#         even_count += 1
# print("even length words in given string are :", even_count)
print("=================================================================================================================")
# Python program to capitalize the first and last character of each word in a string
# str1 = input("Enter a sentence :")
# lst = str1.title().split()
# print(lst)
# string = ""
# string1 = ""
# for i in lst:
#     string = i[:-1] + i[-1].upper()
#     string1 = string1 + string + " "
# print(string1)
# for i in lst:
#     string += i[:-1] + i[-1].upper() + " "
# print(string)
print("=================================================================================================================")
# Python program to check if a string has at least one letter and one number
# string = input('Enter a input string :\n')
# flag1, flag2 = False, False
# for i in string:
#     if i.isalpha():
#         flag1 = True
#     if i.isnumeric():
#         flag2 = True
# if flag1 and flag2:
#     print("Your string consist of both letters and numbers.")
# else:
#     if not flag1 and flag2:
#         print("Letter is missing in your string.")
#     elif not flag2 and flag1:
#         print("number is missing in your string.")
#     else:
#         print("Both number and letter missing in your string.")
print("=================================================================================================================")
# Python | Program to accept the strings which contains all vowels
# string = input("Enter the string :")
# string = string.lower()
# lst = ['a','e','i','o','u']
# lst1 = []
# for i in range(len(string)):
#     if (string[i] in lst) and (string[i] not in lst1) :
#         lst1.append(string[i])
# if len(lst1) == 5:
#     print("String contains all vowels.")
# else:
#     print("Something is missing in your string.")

# lst2 = [string.count('a'),string.count('e'),string.count('i'),string.count('o'),string.count('u')]
#
# if lst2.count(0) > 0:
#     print("not accepted")
# else:
#     print("accepted")
print("=================================================================================================================")
year = int(input("Year :"))
if year % 400 == 0 or (year % 4 == 0 and year % 100 != 0):
    print("leap year")
else:
    print("not leap year")