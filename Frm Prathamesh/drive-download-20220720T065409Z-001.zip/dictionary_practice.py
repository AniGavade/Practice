# # Sort Python Dictionaries by Key or Value
# def get(var):
#     for i in range(len(var)):
#         print(var[i],end=" ")
#     print()
#
# dict_1 = {}
#
# dict_1[5] = 36
# dict_1[3] = 59
# dict_1[8] = 92
# dict_1[2] = 11
# dict_1[6] = 105
# dict_1[2] = 49
# dict_1[1] = 76
# dict_1[7] = 82
# dict_1[4] = 27
# print(dict_1)
#
# key = sorted(dict_1.keys())
#
# val = sorted(dict_1.values())
#
# key_val = sorted(dict_1.items())
#
# get(key_val)
#
# get(key)
#
# get(val)
# ================================================================

# get(key,def_val) method is useful when we have to check for the key.
# If the key is present, the value associated with the key is printed,
# else the def_value passed in arguments is returned.
# dict_2 = {"red": "apple", "yellow": "mango", "green": "grapes", "orange": "orange"}
#
# print(dict_2)
#
# # searching for key which is present in dictionary
# val1 = dict_2.get("red", "not defined")
# print(val1)
#
# # searching for key which is not present in dictionary
# val2 = dict_2.get("black", "not defined")
# print(val2)
# ===================================================================================
# # a dictionary with multiple inputs in a key.

# # creating an empty dictionary
# dict_3 = {}
#
# # Insert first triplet in dictionary
# x, y, z = 3, 4, 5
# dict_3[x, y, z] = x + y + z;
#
# # Insert second triplet in dictionary
# x, y, z = 5, 12, 13
# dict_3[x, y, z] = x + y + z;
#
# # print the dictionary
# print(dict_3)
# x, y, z = 3, 4, 5
# del dict_3[x, y, z]
#
# print(dict_3)
# x, y, z = 6, 8, 10
# dict_3.update({(x, y, z) : x + y + z})
# print(dict_3)
# ===================================================================================
# # dictionary containing longitude and latitude of places
# places = {("19.07'53.2", "72.54'51.0"): "Mumbai",
#           ("28.33'34.1", "77.06'16.6"): "Delhi"}
#
# print(places)
# print()
#
# # Traversing dictionary with multi-keys and creating different lists from it
# latitude = []
# longitude = []
# place = []
# for i in places:
#     latitude.append(i[0])
#     longitude.append(i[1])
#     place.append(places[i[0], i[1]])
#
#
# print(latitude)
# print(longitude)
# print(place)
# ===================================================================================