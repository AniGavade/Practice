# a = 10
# b = 20
# print("Initial values of a and b are :", a, ",", b)
#
# # METHOD 1
# temp = a
# a = b
# b = temp
# print("Values of a and b after swapping are :", a, " ,", b)
#
# # METHOD 2
# a = a + b
# b = a - b
# a = a - b
# print("Values of a and b after swapping are :", a, ",", b)
#
# # METHOD 3
# a = a ^ b
# b = a ^ b
# a = a ^ b
# print("Values of a and b after swapping are :", a, ",", b)
#
# # METHOD 4
# a, b = b, a
# print("Values of a and b after swapping are :", a, ",", b)

# count() - returns the count of given sub-string occured in string, if found nothing returns 0
# var1 = 'we are learning python.'
# print(var1.count('e'))
# print(var1.count('ee'))
#
# print('==========================================================================================================')
#
# # find() - returns the index position of first occurence of given substring, if not found returns -1
# print(var1.find('e'))
# print(var1.find('e',2))   # here we can also specify from where we want find the specific substring
# print(var1.find('z'))
#
# print('==========================================================================================================')
#
# # index() - returns the index position of first occurence of given substring, if not found returns error
#
# print(var1.find('e'))
# print(var1.find('e',2))   # here we can also specify from where we want index position of the specific substring
# print(var1.find('z'))





